﻿namespace WinFormsApp6
{
    partial class frmMass
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmdStart = new Button();
            cmdExit = new Button();
            cmdClear = new Button();
            dgvMass = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtn = new TextBox();
            txtm = new TextBox();
            txtRez = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvMass).BeginInit();
            SuspendLayout();
            // 
            // cmdStart
            // 
            cmdStart.Location = new Point(60, 525);
            cmdStart.Margin = new Padding(4);
            cmdStart.Name = "cmdStart";
            cmdStart.Size = new Size(393, 41);
            cmdStart.TabIndex = 0;
            cmdStart.Text = "Вычислить";
            cmdStart.UseVisualStyleBackColor = true;
            cmdStart.Click += cmdStart_Click;
            // 
            // cmdExit
            // 
            cmdExit.Location = new Point(910, 525);
            cmdExit.Margin = new Padding(4);
            cmdExit.Name = "cmdExit";
            cmdExit.Size = new Size(393, 41);
            cmdExit.TabIndex = 1;
            cmdExit.Text = "Завершить работу\r\n";
            cmdExit.UseVisualStyleBackColor = true;
            cmdExit.Click += cmdExit_Click;
            // 
            // cmdClear
            // 
            cmdClear.Location = new Point(484, 525);
            cmdClear.Margin = new Padding(4);
            cmdClear.Name = "cmdClear";
            cmdClear.Size = new Size(393, 41);
            cmdClear.TabIndex = 2;
            cmdClear.Text = "Очистка полей";
            cmdClear.UseVisualStyleBackColor = true;
            cmdClear.Click += button3_Click;
            // 
            // dgvMass
            // 
            dgvMass.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMass.Location = new Point(619, 19);
            dgvMass.Margin = new Padding(4);
            dgvMass.Name = "dgvMass";
            dgvMass.RowHeadersWidth = 51;
            dgvMass.RowTemplate.Height = 29;
            dgvMass.Size = new Size(646, 486);
            dgvMass.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(60, 40);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(217, 28);
            label1.TabIndex = 4;
            label1.Text = "Количевство строк n=";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(60, 139);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(259, 28);
            label2.TabIndex = 5;
            label2.Text = "Количевство столбцов m=";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(60, 252);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(103, 28);
            label3.TabIndex = 6;
            label3.Text = "Результат:";
            // 
            // txtn
            // 
            txtn.Location = new Point(60, 72);
            txtn.Margin = new Padding(4);
            txtn.Name = "txtn";
            txtn.Size = new Size(259, 34);
            txtn.TabIndex = 7;
            // 
            // txtm
            // 
            txtm.Location = new Point(60, 171);
            txtm.Margin = new Padding(4);
            txtm.Name = "txtm";
            txtm.Size = new Size(259, 34);
            txtm.TabIndex = 8;
            // 
            // txtRez
            // 
            txtRez.Location = new Point(60, 284);
            txtRez.Margin = new Padding(4);
            txtRez.Multiline = true;
            txtRez.Name = "txtRez";
            txtRez.Size = new Size(532, 182);
            txtRez.TabIndex = 9;
            // 
            // frmMass
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1316, 826);
            Controls.Add(txtRez);
            Controls.Add(txtm);
            Controls.Add(txtn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvMass);
            Controls.Add(cmdClear);
            Controls.Add(cmdExit);
            Controls.Add(cmdStart);
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "frmMass";
            Text = "Двумерные масивы";
            ((System.ComponentModel.ISupportInitialize)dgvMass).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button cmdStart;
        private Button cmdExit;
        private Button cmdClear;
        private DataGridView dgvMass;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtn;
        private TextBox txtm;
        private TextBox txtRez;
    }
}